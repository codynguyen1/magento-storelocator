<?php

namespace Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid\Tag;

class Index extends \Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid {
    
}
