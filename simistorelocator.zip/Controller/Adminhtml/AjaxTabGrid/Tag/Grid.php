<?php

namespace Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid\Tag;

class Grid extends \Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid {
    
}
