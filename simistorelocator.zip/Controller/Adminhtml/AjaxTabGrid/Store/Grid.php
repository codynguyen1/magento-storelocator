<?php

namespace Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid\Store;

class Grid extends \Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid {
    
}
