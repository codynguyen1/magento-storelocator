<?php

namespace Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid\Store;

class Index extends \Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid {
    
}
