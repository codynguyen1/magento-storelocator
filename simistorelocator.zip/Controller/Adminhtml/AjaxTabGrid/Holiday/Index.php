<?php

namespace Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid\Holiday;

class Index extends \Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid {
    
}
