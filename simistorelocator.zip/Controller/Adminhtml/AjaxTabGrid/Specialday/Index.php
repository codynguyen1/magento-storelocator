<?php

namespace Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid\Specialday;

class Index extends \Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid {
    
}
