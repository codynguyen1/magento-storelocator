<?php

namespace Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid\Specialday;

class Grid extends \Simi\Simistorelocator\Controller\Adminhtml\AjaxTabGrid {
    
}
