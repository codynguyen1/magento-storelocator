<?php

namespace Simi\Simistorelocator\Block\Adminhtml\Widget\Form\Renderer;

class Fieldset extends \Magento\Backend\Block\Widget\Form\Renderer\Fieldset {

    /**
     * @var string
     */
    protected $_template = 'Simi_Simistorelocator::widget/form/renderer/fieldset.phtml';

}
