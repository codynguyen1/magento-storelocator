var config = {
    map: {
       '*': {
           'simi/map-loader' : 'Simi_Simistorelocator/js/store/map/map-loader',
           'simi/region-updater' : 'Simi_Simistorelocator/js/store/region-updater',
       }
    },
    paths: {
    },
};
