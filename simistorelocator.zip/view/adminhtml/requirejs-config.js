var config = {
    map: {
       '*': {
            'simi/weekdaytime' : 'Simi_Simistorelocator/js/weekdaytime',
            'simi/utilities' : 'Simi_Simistorelocator/js/utilities',
            'simi/schedule' : 'Simi_Simistorelocator/js/form/schedule',
            'simi/specialday' : 'Simi_Simistorelocator/js/form/specialday',
            'simi/map': 'Simi_Simistorelocator/js/store/map',
            'simi/baseimage': 'Simi_Simistorelocator/js/gallery/base-image-uploader',
       }
    },
    paths: {
    },
};
